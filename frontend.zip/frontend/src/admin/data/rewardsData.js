/* =========================================================
   DUMMY DATA — Admin › Rewards
   UI only. No backend. Matches the user-side "Orbit Points" page:
   points are earned from buying, donating, reviewing and community
   actions, and spent on vouchers.
   ========================================================= */

import { DEMO_TODAY } from "../utils/format";

const DAY = 86400000;
const dayISO = (offset) => new Date(new Date(DEMO_TODAY).setHours(0, 0, 0, 0) + offset * DAY).toISOString().slice(0, 10);

export const LEVELS = [
  { key: "seedling", name: "Seedling", min: 0 },
  { key: "sprout", name: "Sprout", min: 500 },
  { key: "orbiter", name: "Orbiter", min: 1500 },
  { key: "guardian", name: "Guardian", min: 3000 },
  { key: "champion", name: "Champion", min: 5000 },
];
export const levelFor = (lifetime) => [...LEVELS].reverse().find((l) => lifetime >= l.min);

/* How points are earned. Donation rules feed the Donations module. */
export const INITIAL_RULES = [
  { id: "purchase", group: "Buying", title: "Marketplace purchase", description: "Points for every ₹100 spent on a completed order.", points: 10, unit: "per ₹100 spent", active: true },
  { id: "firstOrder", group: "Buying", title: "First order bonus", description: "A welcome bonus on a user’s first completed order.", points: 50, unit: "one time", active: true },
  { id: "donationBase", group: "Donating", title: "Donation completed", description: "Credited when a donation reaches Completed and the certificate is issued.", points: 100, unit: "per donation", active: true, donation: true },
  { id: "donationItem", group: "Donating", title: "Extra for every item donated", description: "Added on top, for each item in the donation.", points: 20, unit: "per item", active: true, donation: true },
  { id: "listing", group: "Community", title: "Item verified and listed", description: "When an uploaded item passes verification.", points: 30, unit: "per item", active: true },
  { id: "review", group: "Community", title: "Write a review", description: "For each approved review.", points: 20, unit: "per review", active: true },
  { id: "referral", group: "Community", title: "Refer a friend", description: "When a friend you invited completes a first order.", points: 150, unit: "per friend", active: false },
  { id: "follow", group: "Community", title: "Follow a ReMaker", description: "Small reward for following, up to 10 ReMakers.", points: 5, unit: "per follow", active: true },
];

/* kind "points" = users spend Orbit Points to get it. kind "code" = a public coupon code. */
export const INITIAL_VOUCHERS = [
  { id: "VCH-1001", code: "ORBIT100", title: "₹100 Marketplace Voucher", description: "Save on the next sustainable purchase.", kind: "points", discount_type: "fixed", value: 100, min_order: 499, max_discount: 100, points_cost: 500, usage_limit: 500, per_user: 3, used: 164, valid_from: dayISO(-120), valid_to: dayISO(120), audience: "Everyone", paused: false, draft: false },
  { id: "VCH-1002", code: "FREEDEL", title: "Free Delivery", description: "Free delivery on one eligible order.", kind: "points", discount_type: "fixed", value: 99, min_order: 299, max_discount: 99, points_cost: 750, usage_limit: 300, per_user: 2, used: 87, valid_from: dayISO(-90), valid_to: dayISO(90), audience: "Everyone", paused: false, draft: false },
  { id: "VCH-1003", code: "GREEN250", title: "₹250 Sustainability Voucher", description: "A bigger reward for the next order.", kind: "points", discount_type: "fixed", value: 250, min_order: 999, max_discount: 250, points_cost: 1200, usage_limit: 200, per_user: 1, used: 41, valid_from: dayISO(-60), valid_to: dayISO(200), audience: "Level Orbiter and above", paused: false, draft: false },
  { id: "VCH-1004", code: "WELCOME10", title: "Welcome 10% off", description: "10% off the first order, for new users.", kind: "code", discount_type: "percent", value: 10, min_order: 299, max_discount: 150, points_cost: 0, usage_limit: 2000, per_user: 1, used: 612, valid_from: dayISO(-200), valid_to: dayISO(160), audience: "New users", paused: false, draft: false },
  { id: "VCH-1005", code: "DIWALI15", title: "Diwali Green Sale", description: "15% off all upcycled products during Diwali week.", kind: "code", discount_type: "percent", value: 15, min_order: 799, max_discount: 400, points_cost: 0, usage_limit: 1000, per_user: 1, used: 0, valid_from: dayISO(3), valid_to: dayISO(12), audience: "Everyone", paused: false, draft: false },
  { id: "VCH-1006", code: "THANKS50", title: "Donor Thank-you ₹50", description: "A thank-you coupon for users who completed a donation.", kind: "code", discount_type: "fixed", value: 50, min_order: 199, max_discount: 50, points_cost: 0, usage_limit: 800, per_user: 2, used: 233, valid_from: dayISO(-150), valid_to: dayISO(5), audience: "Donors", paused: false, draft: false },
  { id: "VCH-1007", code: "REMAKER20", title: "ReMaker Spotlight 20%", description: "20% off products from featured ReMakers.", kind: "code", discount_type: "percent", value: 20, min_order: 999, max_discount: 500, points_cost: 0, usage_limit: 300, per_user: 1, used: 289, valid_from: dayISO(-40), valid_to: dayISO(40), audience: "Everyone", paused: false, draft: false },
  { id: "VCH-1008", code: "MONSOON10", title: "Monsoon Clearance", description: "10% off furniture. Ran during the monsoon sale.", kind: "code", discount_type: "percent", value: 10, min_order: 1499, max_discount: 600, points_cost: 0, usage_limit: 500, per_user: 1, used: 318, valid_from: dayISO(-120), valid_to: dayISO(-30), audience: "Everyone", paused: false, draft: false },
  { id: "VCH-1009", code: "DECOR150", title: "₹150 Home Decor Voucher", description: "For home decor and lighting.", kind: "points", discount_type: "fixed", value: 150, min_order: 699, max_discount: 150, points_cost: 900, usage_limit: 150, per_user: 2, used: 22, valid_from: dayISO(-30), valid_to: dayISO(150), audience: "Everyone", paused: true, draft: false },
  { id: "VCH-1010", code: "PICKUPPASS", title: "Priority Pickup Pass", description: "Jump the queue for one platform pickup.", kind: "points", discount_type: "fixed", value: 0, min_order: 0, max_discount: 0, points_cost: 400, usage_limit: 100, per_user: 1, used: 100, valid_from: dayISO(-80), valid_to: dayISO(60), audience: "Everyone", paused: false, draft: false },
  { id: "VCH-1011", code: "BIGBANG30", title: "Anniversary 30% off", description: "ReOrbit’s anniversary offer. Not live yet.", kind: "code", discount_type: "percent", value: 30, min_order: 1999, max_discount: 1000, points_cost: 0, usage_limit: 200, per_user: 1, used: 0, valid_from: dayISO(30), valid_to: dayISO(37), audience: "Everyone", paused: false, draft: true },
  { id: "VCH-1012", code: "BOOKS5", title: "Books ₹50 off", description: "₹50 off a bundle of books.", kind: "code", discount_type: "fixed", value: 50, min_order: 349, max_discount: 50, points_cost: 0, usage_limit: 400, per_user: 1, used: 96, valid_from: dayISO(-20), valid_to: dayISO(6), audience: "Everyone", paused: false, draft: false },
];

export const NOW_ISO = DEMO_TODAY.toISOString();
export const AUDIENCES = ["Everyone", "New users", "Donors", "Level Orbiter and above", "ReMakers"];
