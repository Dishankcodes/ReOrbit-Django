import { Heart, ShoppingBag, Trash2, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { wishlist, formatPrice } from "../data/mockData";
import "../styles/pages.css";
export default function UserWishlist(){return <div className="page"><div className="page-head"><div><span className="eyebrow">SAVED FOR LATER</span><h2>Your Wishlist</h2><p>Keep the pieces you love close until they find their next orbit.</p></div><span className="count-chip"><Heart size={13}/> {wishlist.length} saved</span></div><div className="wishlist-grid">{wishlist.map(p=><article className="product-card card" key={p.id}><div className="product-image"><img src={p.image} alt=""/><button><Trash2 size={15}/></button></div><div className="product-copy"><span>{p.category}</span><h4>{p.title}</h4><p>{p.seller}</p><div><strong>{formatPrice(p.price)}</strong><Link to={`/user-marketplace/product/${p.id}`}><ShoppingBag size={13}/> View</Link></div></div></article>)}</div></div>}
