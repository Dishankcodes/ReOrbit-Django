import React, { useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  ITEMS,
  getItemById,
  getSellerFromItem,
  getSellerReviews,
  getProductsBySeller,
  formatPrice,
} from "../../data/marketplaceData";
import "../../css/marketplace-css/UserProductDetails.css";

function ImageWithFallback({ src, alt, className = "" }) {
  const [failed, setFailed] = useState(false);

  if (failed || !src) {
    return (
      <div className={`upd-image-fallback ${className}`}>
        <i className="bi bi-box-seam"></i>
      </div>
    );
  }

  return (
    <img
      className={className}
      src={src}
      alt={alt}
      onError={() => setFailed(true)}
    />
  );
}

function Stars({ rating = 0 }) {
  return (
    <span className="upd-stars">
      {[1, 2, 3, 4, 5].map((star) => (
        <i
          key={star}
          className={
            star <= Math.round(rating) ? "bi bi-star-fill" : "bi bi-star"
          }
        ></i>
      ))}
    </span>
  );
}

export default function UserProductDetails() {
  const { productId } = useParams();
  const navigate = useNavigate();

  const item = getItemById(productId);

  const [activeImage, setActiveImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [liked, setLiked] = useState(false);
  const [addedToCart, setAddedToCart] = useState(false);
  const [activeTab, setActiveTab] = useState("description");

  const seller = useMemo(() => getSellerFromItem(item), [item]);

  const sellerReviews = useMemo(
    () => (item ? getSellerReviews(item.sellerId) : []),
    [item],
  );

  const sellerProducts = useMemo(
    () => (item ? getProductsBySeller(item.sellerId) : []),
    [item],
  );

  if (!item) {
    return (
      <main className="upd-page">
        <div className="upd-not-found">
          <div className="upd-not-found-icon">
            <i className="bi bi-box"></i>
          </div>

          <h1>Product not found</h1>

          <p>
            The product you're looking for may have been removed or is no longer
            available.
          </p>

          <button type="button" onClick={() => navigate("/user-marketplace")}>
            <i className="bi bi-arrow-left"></i>
            Back to marketplace
          </button>
        </div>
      </main>
    );
  }

  const productImages = [item.image, item.image, item.image];

  const total = item.price * quantity;

  const openSellerProfile = () => {
    if (item.sellerType === "remaker") {
      navigate(`/user-artist-profile/${item.sellerId}`);
    } else {
      navigate(`/user-seller-profile/${item.sellerId}`);
    }
  };

  const openProduct = (id) => {
    navigate(`/user-marketplace/product/${id}`);
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  const addToCart = () => {
    setAddedToCart(true);

    window.setTimeout(() => {
      setAddedToCart(false);
    }, 2500);
  };

  const buyNow = () => {
    addToCart();
  };

  return (
    <main className="upd-page">
      <div className="upd-container">
        <div className="upd-breadcrumb">
          <button type="button" onClick={() => navigate("/user-marketplace")}>
            Marketplace
          </button>

          <i className="bi bi-chevron-right"></i>

          <span>{item.category}</span>

          <i className="bi bi-chevron-right"></i>

          <span>{item.title}</span>
        </div>

        <button
          type="button"
          className="upd-back-button"
          onClick={() => navigate(-1)}
        >
          <i className="bi bi-arrow-left"></i>
          Back
        </button>

        <section className="upd-main">
          <div className="upd-gallery">
            <div className="upd-thumbnails">
              {productImages.map((image, index) => (
                <button
                  type="button"
                  key={`${image}-${index}`}
                  className={activeImage === index ? "active" : ""}
                  onClick={() => setActiveImage(index)}
                >
                  <ImageWithFallback
                    src={image}
                    alt={`${item.title} ${index + 1}`}
                  />
                </button>
              ))}
            </div>

            <div className="upd-main-image">
              <ImageWithFallback
                src={productImages[activeImage]}
                alt={item.title}
              />

              <div className="upd-image-badge">
                <i className="bi bi-leaf"></i>
                {item.co2SavedKg} kg CO₂ saved
              </div>

              <button
                type="button"
                className={`upd-like ${liked ? "active" : ""}`}
                onClick={() => setLiked((current) => !current)}
              >
                <i className={liked ? "bi bi-heart-fill" : "bi bi-heart"}></i>
              </button>
            </div>
          </div>

          <div className="upd-info">
            <div className="upd-category">{item.category}</div>

            <h1>{item.title}</h1>

            <div className="upd-rating-line">
              <Stars rating={item.sellerRating} />

              <strong>{item.sellerRating}</strong>

              <span>Seller rating</span>

              <span className="upd-dot">•</span>

              <span>{item.condition}</span>
            </div>

            <div className="upd-price">
              <span>{formatPrice(item.price)}</span>
              <small>incl. marketplace listing price</small>
            </div>

            <p className="upd-summary">{item.summary}</p>

            <div className="upd-location-box">
              <i className="bi bi-geo-alt"></i>

              <div>
                <strong>Located in {item.city}</strong>
                <span>Pincode {item.pincode}</span>
              </div>
            </div>

            <div className="upd-divider"></div>

            <div className="upd-quantity-row">
              <span>Quantity</span>

              <div className="upd-quantity">
                <button
                  type="button"
                  onClick={() =>
                    setQuantity((current) => Math.max(1, current - 1))
                  }
                >
                  <i className="bi bi-dash"></i>
                </button>

                <strong>{quantity}</strong>

                <button
                  type="button"
                  onClick={() =>
                    setQuantity((current) =>
                      Math.min(item.quantity || 10, current + 1),
                    )
                  }
                >
                  <i className="bi bi-plus"></i>
                </button>
              </div>
            </div>

            <div className="upd-actions">
              <button
                type="button"
                className={`upd-cart ${addedToCart ? "success" : ""}`}
                onClick={addToCart}
              >
                <i
                  className={addedToCart ? "bi bi-check-lg" : "bi bi-bag-plus"}
                ></i>

                {addedToCart ? "Added to Cart" : "Add to Cart"}
              </button>

              <button type="button" className="upd-buy" onClick={buyNow}>
                Buy Now
                <i className="bi bi-arrow-right"></i>
              </button>
            </div>

            <div className="upd-safe-row">
              <div>
                <i className="bi bi-shield-check"></i>
                <span>Community marketplace</span>
              </div>

              <div>
                <i className="bi bi-recycle"></i>
                <span>Second-life product</span>
              </div>
            </div>
          </div>
        </section>

        <section className="upd-seller-section">
          <div className="upd-section-heading">
            <span>Meet the seller</span>
            <h2>
              {item.sellerType === "remaker"
                ? "Made by a ReMaker"
                : "Listed by a community seller"}
            </h2>
          </div>

          <div className="upd-seller-card">
            <div className="upd-seller-identity">
              <div className="upd-seller-avatar">
                {seller?.image ? (
                  <img
                    src={seller.image}
                    alt={seller.name}
                    onError={(event) => {
                      event.currentTarget.style.display = "none";
                    }}
                  />
                ) : (
                  <span>
                    {seller?.name
                      ?.split(" ")
                      .map((word) => word[0])
                      .join("")
                      .slice(0, 2)}
                  </span>
                )}
              </div>

              <div>
                <div className="upd-seller-name-row">
                  <h3>{seller?.name || item.seller}</h3>

                  {item.sellerType === "remaker" && (
                    <span className="upd-verified">
                      <i className="bi bi-patch-check-fill"></i>
                      Verified ReMaker
                    </span>
                  )}
                </div>

                <p>
                  {item.sellerType === "remaker"
                    ? seller?.craft
                    : `Seller in ${seller?.city || item.city}`}
                </p>

                <div className="upd-seller-meta">
                  <span>
                    <i className="bi bi-star-fill"></i>
                    {seller?.rating || item.sellerRating}
                  </span>

                  <span>
                    <i className="bi bi-box-seam"></i>
                    {sellerProducts.length} products
                  </span>

                  {item.sellerType === "remaker" && (
                    <span>
                      <i className="bi bi-people"></i>
                      {seller?.followers || 0} followers
                    </span>
                  )}
                </div>
              </div>
            </div>

            <button
              type="button"
              className="upd-profile-button"
              onClick={openSellerProfile}
            >
              {item.sellerType === "remaker"
                ? "View Artist Profile"
                : "View Seller Profile"}
              <i className="bi bi-arrow-right"></i>
            </button>
          </div>
        </section>

        <section className="upd-details-section">
          <div className="upd-tabs">
            <button
              type="button"
              className={activeTab === "description" ? "active" : ""}
              onClick={() => setActiveTab("description")}
            >
              Description
            </button>

            <button
              type="button"
              className={activeTab === "condition" ? "active" : ""}
              onClick={() => setActiveTab("condition")}
            >
              Condition
            </button>

            <button
              type="button"
              className={activeTab === "impact" ? "active" : ""}
              onClick={() => setActiveTab("impact")}
            >
              Environmental Impact
            </button>

            <button
              type="button"
              className={activeTab === "reviews" ? "active" : ""}
              onClick={() => setActiveTab("reviews")}
            >
              Seller Reviews
            </button>
          </div>

          <div className="upd-tab-content">
            {activeTab === "description" && (
              <div className="upd-description">
                <h3>About this item</h3>

                <p>{item.description || item.summary}</p>

                <div className="upd-spec-grid">
                  <div>
                    <span>Category</span>
                    <strong>{item.category}</strong>
                  </div>

                  <div>
                    <span>Condition</span>
                    <strong>{item.condition}</strong>
                  </div>

                  <div>
                    <span>Location</span>
                    <strong>{item.city}</strong>
                  </div>

                  <div>
                    <span>CO₂ saved</span>
                    <strong>{item.co2SavedKg} kg</strong>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "condition" && (
              <div className="upd-description">
                <h3>Product condition</h3>

                <div className="upd-condition-highlight">
                  <div>
                    <i className="bi bi-check-circle"></i>
                  </div>

                  <div>
                    <strong>{item.condition}</strong>
                    <p>
                      This item's condition has been provided by the seller and
                      is displayed for transparency before purchase.
                    </p>
                  </div>
                </div>

                <p>
                  Please review the product description and images carefully
                  before making a purchase.
                </p>
              </div>
            )}

            {activeTab === "impact" && (
              <div className="upd-impact-content">
                <div className="upd-impact-main">
                  <div className="upd-impact-icon">
                    <i className="bi bi-leaf"></i>
                  </div>

                  <div>
                    <span>Estimated impact</span>
                    <strong>{item.co2SavedKg} kg</strong>
                    <p>
                      Estimated CO₂ savings associated with keeping this item in
                      use.
                    </p>
                  </div>
                </div>

                <div className="upd-impact-points">
                  <div>
                    <i className="bi bi-arrow-repeat"></i>
                    <span>Extended product life</span>
                  </div>

                  <div>
                    <i className="bi bi-trash3"></i>
                    <span>Less material waste</span>
                  </div>

                  <div>
                    <i className="bi bi-globe2"></i>
                    <span>Circular consumption</span>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "reviews" && (
              <div className="upd-reviews">
                {sellerReviews.length > 0 ? (
                  sellerReviews.map((review) => (
                    <div className="upd-review" key={review.id}>
                      <div className="upd-review-top">
                        <strong>{review.name}</strong>

                        <div>
                          <Stars rating={review.rating} />

                          <span>{review.date}</span>
                        </div>
                      </div>

                      <p>{review.text}</p>
                    </div>
                  ))
                ) : (
                  <div className="upd-no-reviews">
                    <i className="bi bi-chat-square-text"></i>
                    <p>No seller reviews yet.</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </section>

        {sellerProducts.length > 1 && (
          <section className="upd-related-section">
            <div className="upd-section-heading">
              <span>More from this seller</span>
              <h2>You may also like</h2>
            </div>

            <div className="upd-related-grid">
              {sellerProducts
                .filter((product) => product.id !== item.id)
                .slice(0, 4)
                .map((product) => (
                  <button
                    type="button"
                    className="upd-related-card"
                    key={product.id}
                    onClick={() => openProduct(product.id)}
                  >
                    <div className="upd-related-image">
                      <ImageWithFallback
                        src={product.image}
                        alt={product.title}
                      />
                    </div>

                    <div>
                      <span>{product.category}</span>

                      <h3>{product.title}</h3>

                      <strong>{formatPrice(product.price)}</strong>
                    </div>
                  </button>
                ))}
            </div>
          </section>
        )}
      </div>

      {addedToCart && (
        <div className="upd-toast">
          <div>
            <i className="bi bi-check-circle-fill"></i>
          </div>

          <span>
            {quantity} item
            {quantity > 1 ? "s" : ""} added to your cart.
          </span>

          <button type="button" onClick={() => setAddedToCart(false)}>
            <i className="bi bi-x"></i>
          </button>
        </div>
      )}
    </main>
  );
}
