import React, { useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  getRemakerById,
  getRemakerProducts,
  getSellerReviews,
  formatPrice,
} from "../../data/marketplaceData";
import "../../css/marketplace-css/UserArtistProfile.css";

function ImageWithFallback({ src, alt }) {
  const [failed, setFailed] = useState(false);

  if (failed || !src) {
    return (
      <div className="uap-image-fallback">
        <i className="bi bi-image"></i>
      </div>
    );
  }

  return <img src={src} alt={alt} onError={() => setFailed(true)} />;
}

function Stars({ rating }) {
  return (
    <span className="uap-stars">
      {[1, 2, 3, 4, 5].map((star) => (
        <i
          key={star}
          className={
            star <= Math.round(rating) ? "bi bi-star-fill" : "bi bi-star"
          }
        ></i>
      ))}
    </span>
  );
}

export default function UserArtistProfile() {
  const { artistId } = useParams();
  const navigate = useNavigate();

  const artist = getRemakerById(artistId);
  const products = getRemakerProducts(artistId);
  const reviews = getSellerReviews(artistId);

  const [following, setFollowing] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");

  const averageRating = artist?.rating || 0;

  const totalProducts = useMemo(
    () => (artist ? Math.max(artist.productsCount || 0, products.length) : 0),
    [artist, products.length],
  );

  if (!artist) {
    return (
      <main className="uap-page">
        <div className="uap-not-found">
          <div>
            <i className="bi bi-person-workspace"></i>
          </div>

          <h1>ReMaker not found</h1>

          <p>This ReMaker profile is no longer available.</p>

          <button type="button" onClick={() => navigate("/user-marketplace")}>
            <i className="bi bi-arrow-left"></i>
            Back to marketplace
          </button>
        </div>
      </main>
    );
  }

  return (
    <main className="uap-page">
      <div className="uap-container">
        <button type="button" className="uap-back" onClick={() => navigate(-1)}>
          <i className="bi bi-arrow-left"></i>
          Back
        </button>

        <section className="uap-hero">
          <div className="uap-hero-background">
            <div className="uap-hero-circle circle-one"></div>
            <div className="uap-hero-circle circle-two"></div>
            <div className="uap-hero-lines"></div>
          </div>

          <div className="uap-hero-content">
            <div className="uap-artist-avatar">
              <ImageWithFallback src={artist.image} alt={artist.name} />

              {artist.verified && (
                <span className="uap-avatar-verified">
                  <i className="bi bi-patch-check-fill"></i>
                </span>
              )}
            </div>

            <div className="uap-artist-intro">
              <div className="uap-artist-badge">
                <i className="bi bi-patch-check-fill"></i>
                Verified ReMaker
              </div>

              <h1>{artist.name}</h1>

              <h2>{artist.craft}</h2>

              <div className="uap-location">
                <i className="bi bi-geo-alt"></i>
                {artist.city} · {artist.pincode}
              </div>

              <p>{artist.bio}</p>

              <div className="uap-hero-actions">
                <button
                  type="button"
                  className={following ? "uap-follow following" : "uap-follow"}
                  onClick={() => setFollowing((current) => !current)}
                >
                  <i
                    className={
                      following ? "bi bi-check-lg" : "bi bi-person-plus"
                    }
                  ></i>

                  {following ? "Following" : "Follow ReMaker"}
                </button>

                <button type="button" className="uap-message">
                  <i className="bi bi-chat"></i>
                  Contact
                </button>
              </div>
            </div>

            <div className="uap-rating-card">
              <span>Artist rating</span>

              <strong>{averageRating}</strong>

              <Stars rating={averageRating} />

              <small>{artist.totalReviews} reviews</small>
            </div>
          </div>
        </section>

        <section className="uap-impact-bar">
          <div>
            <i className="bi bi-recycle"></i>
            <span>Items rescued</span>
            <strong>{artist.itemsRescued}</strong>
          </div>

          <div>
            <i className="bi bi-box-seam"></i>
            <span>Products</span>
            <strong>{totalProducts}</strong>
          </div>

          <div>
            <i className="bi bi-people"></i>
            <span>Followers</span>
            <strong>{artist.followers}</strong>
          </div>

          <div>
            <i className="bi bi-clock-history"></i>
            <span>Experience</span>
            <strong>{artist.yearsOfExperience} years</strong>
          </div>
        </section>

        <section className="uap-content">
          <nav className="uap-tabs">
            <button
              type="button"
              className={activeTab === "overview" ? "active" : ""}
              onClick={() => setActiveTab("overview")}
            >
              Overview
            </button>

            <button
              type="button"
              className={activeTab === "portfolio" ? "active" : ""}
              onClick={() => setActiveTab("portfolio")}
            >
              Portfolio
              <span>{artist.portfolio?.length || 0}</span>
            </button>

            <button
              type="button"
              className={activeTab === "products" ? "active" : ""}
              onClick={() => setActiveTab("products")}
            >
              Products
              <span>{products.length}</span>
            </button>

            <button
              type="button"
              className={activeTab === "reviews" ? "active" : ""}
              onClick={() => setActiveTab("reviews")}
            >
              Reviews
              <span>{reviews.length}</span>
            </button>
          </nav>

          {activeTab === "overview" && (
            <div className="uap-overview">
              <section className="uap-about-section">
                <div className="uap-section-title">
                  <span>About the ReMaker</span>
                  <h2>Crafting another life for overlooked materials.</h2>
                </div>

                <p>{artist.bio}</p>

                <div className="uap-about-points">
                  <div>
                    <div>
                      <i className="bi bi-recycle"></i>
                    </div>

                    <span>Circular making</span>

                    <p>
                      Materials are given a new purpose instead of being
                      discarded.
                    </p>
                  </div>

                  <div>
                    <div>
                      <i className="bi bi-hand-index"></i>
                    </div>

                    <span>Handcrafted</span>

                    <p>
                      Each piece receives thoughtful attention and individual
                      finishing.
                    </p>
                  </div>

                  <div>
                    <div>
                      <i className="bi bi-leaf"></i>
                    </div>

                    <span>Lower impact</span>

                    <p>
                      Making from existing materials helps keep resources in
                      use.
                    </p>
                  </div>
                </div>
              </section>

              <section className="uap-featured-section">
                <div className="uap-section-title-row">
                  <div className="uap-section-title">
                    <span>Featured work</span>
                    <h2>From the studio</h2>
                  </div>

                  <button
                    type="button"
                    onClick={() => setActiveTab("portfolio")}
                  >
                    View portfolio
                    <i className="bi bi-arrow-right"></i>
                  </button>
                </div>

                <div className="uap-portfolio-preview">
                  {(artist.portfolio || []).slice(0, 3).map((work) => (
                    <article className="uap-portfolio-card" key={work.id}>
                      <div>
                        <ImageWithFallback src={work.image} alt={work.title} />
                      </div>

                      <section>
                        <span>Portfolio</span>
                        <h3>{work.title}</h3>
                        <p>{work.description}</p>
                      </section>
                    </article>
                  ))}
                </div>
              </section>
            </div>
          )}

          {activeTab === "portfolio" && (
            <div className="uap-portfolio-tab">
              <div className="uap-tab-heading">
                <span>Artist portfolio</span>
                <h2>Work by {artist.name}</h2>
                <p>
                  A collection of projects created through restoration, reuse
                  and thoughtful making.
                </p>
              </div>

              <div className="uap-portfolio-grid">
                {(artist.portfolio || []).map((work) => (
                  <article className="uap-large-portfolio" key={work.id}>
                    <div>
                      <ImageWithFallback src={work.image} alt={work.title} />
                    </div>

                    <section>
                      <span>{artist.craft}</span>

                      <h3>{work.title}</h3>

                      <p>{work.description}</p>

                      <button type="button">
                        View project
                        <i className="bi bi-arrow-up-right"></i>
                      </button>
                    </section>
                  </article>
                ))}
              </div>
            </div>
          )}

          {activeTab === "products" && (
            <div className="uap-products-tab">
              <div className="uap-tab-heading">
                <span>Personal products</span>
                <h2>Shop {artist.name}'s work</h2>
                <p>Browse products currently listed by this ReMaker.</p>
              </div>

              <div className="uap-product-grid">
                {products.map((product) => (
                  <button
                    type="button"
                    className="uap-product-card"
                    key={product.id}
                    onClick={() =>
                      navigate(`/user-marketplace/product/${product.id}`)
                    }
                  >
                    <div className="uap-product-image">
                      <ImageWithFallback
                        src={product.image}
                        alt={product.title}
                      />

                      <span>
                        <i className="bi bi-leaf"></i>
                        {product.co2SavedKg} kg CO₂
                      </span>
                    </div>

                    <div className="uap-product-body">
                      <small>{product.category}</small>

                      <h3>{product.title}</h3>

                      <p>{product.summary}</p>

                      <div className="uap-product-footer">
                        <strong>{formatPrice(product.price)}</strong>

                        <span>
                          View
                          <i className="bi bi-arrow-right"></i>
                        </span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {activeTab === "reviews" && (
            <div className="uap-reviews-tab">
              <div className="uap-review-summary">
                <div className="uap-review-score">
                  <strong>{averageRating}</strong>

                  <Stars rating={averageRating} />

                  <span>Based on {artist.totalReviews} reviews</span>
                </div>

                <div className="uap-review-message">
                  <i className="bi bi-heart"></i>

                  <div>
                    <strong>Community feedback</strong>

                    <p>
                      Buyers have shared their experiences with this ReMaker's
                      products and craftsmanship.
                    </p>
                  </div>
                </div>
              </div>

              <div className="uap-review-list">
                {reviews.length > 0 ? (
                  reviews.map((review) => (
                    <article className="uap-review-card" key={review.id}>
                      <div className="uap-review-top">
                        <div>
                          <strong>{review.name}</strong>

                          <Stars rating={review.rating} />
                        </div>

                        <span>{review.date}</span>
                      </div>

                      <p>{review.text}</p>
                    </article>
                  ))
                ) : (
                  <div className="uap-empty">
                    <i className="bi bi-chat-square-text"></i>
                    <h3>No reviews yet</h3>
                  </div>
                )}
              </div>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
