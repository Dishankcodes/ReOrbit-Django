import React, { useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  getUserById,
  getProductsBySeller,
  getSellerReviews,
  formatPrice,
} from "../../data/marketplaceData";
import "../../css/marketplace-css/UserSellerProfile.css";

function ProductImage({ src, alt }) {
  const [failed, setFailed] = useState(false);

  if (failed || !src) {
    return (
      <div className="usp-image-fallback">
        <i className="bi bi-box-seam"></i>
      </div>
    );
  }

  return <img src={src} alt={alt} onError={() => setFailed(true)} />;
}

function Stars({ rating }) {
  return (
    <span className="usp-stars">
      {[1, 2, 3, 4, 5].map((star) => (
        <i
          key={star}
          className={
            star <= Math.round(rating) ? "bi bi-star-fill" : "bi bi-star"
          }
        ></i>
      ))}
    </span>
  );
}

export default function UserSellerProfile() {
  const { sellerId } = useParams();
  const navigate = useNavigate();

  const seller = getUserById(sellerId);
  const products = getProductsBySeller(sellerId);
  const reviews = getSellerReviews(sellerId);

  const [following, setFollowing] = useState(false);
  const [activeTab, setActiveTab] = useState("products");

  if (!seller) {
    return (
      <main className="usp-page">
        <div className="usp-not-found">
          <i className="bi bi-person-x"></i>
          <h1>Seller not found</h1>
          <p>This seller profile is no longer available.</p>

          <button type="button" onClick={() => navigate("/user-marketplace")}>
            Back to marketplace
          </button>
        </div>
      </main>
    );
  }

  return (
    <main className="usp-page">
      <div className="usp-container">
        <button type="button" className="usp-back" onClick={() => navigate(-1)}>
          <i className="bi bi-arrow-left"></i>
          Back
        </button>

        <section className="usp-profile-card">
          <div className="usp-cover">
            <div className="usp-cover-pattern"></div>
          </div>

          <div className="usp-profile-main">
            <div className="usp-avatar">
              {seller.image ? (
                <img
                  src={seller.image}
                  alt={seller.name}
                  onError={(event) => {
                    event.currentTarget.style.display = "none";
                    event.currentTarget.nextElementSibling.style.display =
                      "flex";
                  }}
                />
              ) : null}

              <span>
                {seller.name
                  .split(" ")
                  .map((word) => word[0])
                  .join("")
                  .slice(0, 2)}
              </span>
            </div>

            <div className="usp-profile-info">
              <div className="usp-name-line">
                <div>
                  <h1>{seller.name}</h1>

                  <span className="usp-member-label">
                    <i className="bi bi-person"></i>
                    Community Seller
                  </span>
                </div>

                <button
                  type="button"
                  className={following ? "usp-follow following" : "usp-follow"}
                  onClick={() => setFollowing((current) => !current)}
                >
                  <i
                    className={
                      following ? "bi bi-check-lg" : "bi bi-person-plus"
                    }
                  ></i>

                  {following ? "Following" : "Follow"}
                </button>
              </div>

              <div className="usp-location">
                <i className="bi bi-geo-alt"></i>
                {seller.city} · {seller.pincode}
              </div>

              <p className="usp-bio">{seller.bio}</p>

              <div className="usp-stats">
                <div>
                  <strong>{seller.productsSold}</strong>
                  <span>Products sold</span>
                </div>

                <div>
                  <strong>{products.length}</strong>
                  <span>Listings</span>
                </div>

                <div>
                  <strong>{seller.rating}</strong>
                  <span>Seller rating</span>
                </div>

                <div>
                  <strong>{seller.totalReviews}</strong>
                  <span>Reviews</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="usp-content">
          <div className="usp-tabs">
            <button
              type="button"
              className={activeTab === "products" ? "active" : ""}
              onClick={() => setActiveTab("products")}
            >
              Listings
              <span>{products.length}</span>
            </button>

            <button
              type="button"
              className={activeTab === "reviews" ? "active" : ""}
              onClick={() => setActiveTab("reviews")}
            >
              Reviews
              <span>{reviews.length}</span>
            </button>

            <button
              type="button"
              className={activeTab === "about" ? "active" : ""}
              onClick={() => setActiveTab("about")}
            >
              About
            </button>
          </div>

          {activeTab === "products" && (
            <div className="usp-products">
              <div className="usp-section-title">
                <div>
                  <span>Current listings</span>
                  <h2>Products from {seller.name}</h2>
                </div>

                <div className="usp-sort">
                  <i className="bi bi-grid"></i>
                  {products.length} items
                </div>
              </div>

              {products.length > 0 ? (
                <div className="usp-product-grid">
                  {products.map((product) => (
                    <button
                      type="button"
                      className="usp-product-card"
                      key={product.id}
                      onClick={() =>
                        navigate(`/user-marketplace/product/${product.id}`)
                      }
                    >
                      <div className="usp-product-image">
                        <ProductImage src={product.image} alt={product.title} />

                        <span>{product.condition}</span>
                      </div>

                      <div className="usp-product-content">
                        <small>{product.category}</small>

                        <h3>{product.title}</h3>

                        <div className="usp-product-meta">
                          <span>
                            <i className="bi bi-geo-alt"></i>
                            {product.city}
                          </span>

                          <span>
                            <i className="bi bi-leaf"></i>
                            {product.co2SavedKg} kg
                          </span>
                        </div>

                        <div className="usp-product-bottom">
                          <strong>{formatPrice(product.price)}</strong>

                          <i className="bi bi-arrow-up-right"></i>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="usp-empty">
                  <i className="bi bi-box"></i>
                  <h3>No active listings</h3>
                  <p>This seller doesn't currently have any products listed.</p>
                </div>
              )}
            </div>
          )}

          {activeTab === "reviews" && (
            <div className="usp-reviews">
              <div className="usp-review-summary">
                <div className="usp-big-rating">
                  <strong>{seller.rating}</strong>
                  <Stars rating={seller.rating} />
                  <span>Based on {seller.totalReviews} reviews</span>
                </div>

                <div className="usp-rating-bars">
                  {[5, 4, 3, 2, 1].map((rating) => (
                    <div key={rating}>
                      <span>{rating}</span>

                      <div>
                        <span
                          style={{
                            width:
                              rating === 5
                                ? "82%"
                                : rating === 4
                                  ? "14%"
                                  : "4%",
                          }}
                        ></span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="usp-review-list">
                {reviews.length > 0 ? (
                  reviews.map((review) => (
                    <article className="usp-review-card" key={review.id}>
                      <div className="usp-review-head">
                        <div>
                          <strong>{review.name}</strong>

                          <Stars rating={review.rating} />
                        </div>

                        <span>{review.date}</span>
                      </div>

                      <p>{review.text}</p>
                    </article>
                  ))
                ) : (
                  <div className="usp-empty">
                    <i className="bi bi-chat"></i>
                    <h3>No reviews yet</h3>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === "about" && (
            <div className="usp-about">
              <div className="usp-about-card">
                <span>About the seller</span>

                <h2>A member of the ReOrbit community</h2>

                <p>{seller.bio}</p>

                <div className="usp-about-details">
                  <div>
                    <i className="bi bi-calendar3"></i>
                    <span>Member since {seller.joined}</span>
                  </div>

                  <div>
                    <i className="bi bi-geo-alt"></i>
                    <span>Based in {seller.city}</span>
                  </div>

                  <div>
                    <i className="bi bi-box-seam"></i>
                    <span>{seller.productsSold} products sold</span>
                  </div>

                  <div>
                    <i className="bi bi-star"></i>
                    <span>{seller.rating} seller rating</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
