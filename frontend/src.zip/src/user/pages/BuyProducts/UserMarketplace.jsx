import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  CATEGORIES,
  CONDITIONS,
  ITEMS,
  IMPACT,
  formatPrice,
} from "../../data/marketplaceData";
import "../../css/marketplace-css/UserMarketplace.css";

const getInitials = (name = "") =>
  name
    .split(" ")
    .map((word) => word[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

function ProductImage({ src, alt }) {
  const [failed, setFailed] = useState(false);

  if (failed || !src) {
    return (
      <div className="um-product-image-fallback">
        <i className="bi bi-box-seam"></i>
      </div>
    );
  }

  return <img src={src} alt={alt} onError={() => setFailed(true)} />;
}

function ProductCard({ item, isWishlisted, onWishlist }) {
  const navigate = useNavigate();

  const openProduct = () => {
    navigate(`/user-marketplace/product/${item.id}`);
  };

  const openSeller = (event) => {
    event.stopPropagation();

    if (item.sellerType === "remaker") {
      navigate(`/user-artist-profile/${item.sellerId}`);
    } else {
      navigate(`/user-seller-profile/${item.sellerId}`);
    }
  };

  return (
    <article className="um-product-card">
      <div
        className="um-product-image-wrap"
        onClick={openProduct}
        role="button"
        tabIndex={0}
        onKeyDown={(event) => {
          if (event.key === "Enter") {
            openProduct();
          }
        }}
      >
        <ProductImage src={item.image} alt={item.title} />

        <div className="um-image-top">
          <span className="um-condition-pill">{item.condition}</span>

          <button
            type="button"
            className={`um-wishlist-button ${isWishlisted ? "active" : ""}`}
            onClick={(event) => {
              event.stopPropagation();
              onWishlist(item.id);
            }}
            aria-label={
              isWishlisted ? "Remove from wishlist" : "Add to wishlist"
            }
          >
            <i
              className={isWishlisted ? "bi bi-heart-fill" : "bi bi-heart"}
            ></i>
          </button>
        </div>

        <div className="um-image-bottom">
          <span>
            <i className="bi bi-leaf"></i>
            {item.co2SavedKg} kg CO₂ saved
          </span>
        </div>
      </div>

      <div className="um-product-content">
        <div className="um-product-category">{item.category}</div>

        <h3 onClick={openProduct}>{item.title}</h3>

        <p className="um-product-summary">{item.summary}</p>

        <div className="um-product-location">
          <i className="bi bi-geo-alt"></i>
          <span>
            {item.city} · {item.pincode}
          </span>
        </div>

        <div className="um-product-seller">
          <button type="button" className="um-seller-mini" onClick={openSeller}>
            {item.sellerImage ? (
              <img
                src={item.sellerImage}
                alt={item.seller}
                onError={(event) => {
                  event.currentTarget.style.display = "none";
                  event.currentTarget.nextElementSibling.style.display = "flex";
                }}
              />
            ) : null}

            <span className="um-seller-avatar">{getInitials(item.seller)}</span>

            <span className="um-seller-name">
              {item.seller}
              {item.sellerType === "remaker" && (
                <small>
                  <i className="bi bi-patch-check-fill"></i>
                  ReMaker
                </small>
              )}
            </span>
          </button>

          <div className="um-rating">
            <i className="bi bi-star-fill"></i>
            {item.sellerRating}
          </div>
        </div>

        <div className="um-product-footer">
          <div>
            <span className="um-price-label">Price</span>
            <strong>{formatPrice(item.price)}</strong>
          </div>

          <button
            type="button"
            className="um-view-button"
            onClick={openProduct}
          >
            View
            <i className="bi bi-arrow-right"></i>
          </button>
        </div>
      </div>
    </article>
  );
}

export default function UserMarketplace() {
  const navigate = useNavigate();

  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [condition, setCondition] = useState("All");
  const [sort, setSort] = useState("featured");
  const [view, setView] = useState("grid");
  const [showFilters, setShowFilters] = useState(false);
  const [wishlist, setWishlist] = useState([]);
  const [maxPrice, setMaxPrice] = useState(10000);

  const filteredItems = useMemo(() => {
    let result = [...ITEMS];

    if (search.trim()) {
      const query = search.toLowerCase().trim();

      result = result.filter((item) => {
        return (
          item.title.toLowerCase().includes(query) ||
          item.category.toLowerCase().includes(query) ||
          item.city.toLowerCase().includes(query) ||
          item.seller.toLowerCase().includes(query) ||
          item.summary.toLowerCase().includes(query)
        );
      });
    }

    if (category !== "All") {
      result = result.filter((item) => item.category === category);
    }

    if (condition !== "All") {
      result = result.filter((item) => item.condition === condition);
    }

    result = result.filter((item) => item.price <= Number(maxPrice));

    if (sort === "price-low") {
      result.sort((a, b) => a.price - b.price);
    }

    if (sort === "price-high") {
      result.sort((a, b) => b.price - a.price);
    }

    if (sort === "rating") {
      result.sort((a, b) => b.sellerRating - a.sellerRating);
    }

    if (sort === "co2") {
      result.sort((a, b) => b.co2SavedKg - a.co2SavedKg);
    }

    if (sort === "newest") {
      result.sort((a, b) => new Date(b.listedDate) - new Date(a.listedDate));
    }

    return result;
  }, [search, category, condition, sort, maxPrice]);

  const toggleWishlist = (id) => {
    setWishlist((current) =>
      current.includes(id)
        ? current.filter((itemId) => itemId !== id)
        : [...current, id],
    );
  };

  const clearFilters = () => {
    setSearch("");
    setCategory("All");
    setCondition("All");
    setSort("featured");
    setMaxPrice(10000);
  };

  const hasActiveFilters =
    search || category !== "All" || condition !== "All" || maxPrice < 10000;

  return (
    <main className="um-page">
      <section className="um-hero">
        <div className="um-hero-pattern"></div>

        <div className="um-container um-hero-inner">
          <div className="um-hero-copy">
            <span className="um-eyebrow">
              <i className="bi bi-stars"></i>
              ReOrbit Marketplace
            </span>

            <h1>
              Give good things
              <span> another orbit.</span>
            </h1>

            <p>
              Discover pre-loved, refurbished and thoughtfully remade products
              from people and ReMakers in the ReOrbit community.
            </p>

            <div className="um-hero-stats">
              <div>
                <strong>{IMPACT.itemsRescued.toLocaleString("en-IN")}+</strong>
                <span>Items rescued</span>
              </div>

              <div>
                <strong>{IMPACT.co2SavedTonnes}T</strong>
                <span>CO₂ saved</span>
              </div>

              <div>
                <strong>{IMPACT.remakersOnboarded}</strong>
                <span>ReMakers</span>
              </div>
            </div>
          </div>

          <div className="um-hero-visual">
            <div className="um-hero-orbit">
              <span className="orbit-dot orbit-dot-one"></span>
              <span className="orbit-dot orbit-dot-two"></span>
              <span className="orbit-dot orbit-dot-three"></span>

              <div className="um-orbit-center">
                <i className="bi bi-arrow-repeat"></i>
                <span>ReOrbit</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="um-container">
        <section className="um-search-section">
          <div className="um-search-box">
            <i className="bi bi-search"></i>

            <input
              type="text"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search furniture, decor, electronics, sellers..."
            />

            {search && (
              <button
                type="button"
                onClick={() => setSearch("")}
                aria-label="Clear search"
              >
                <i className="bi bi-x"></i>
              </button>
            )}
          </div>

          <button
            type="button"
            className="um-filter-toggle"
            onClick={() => setShowFilters((current) => !current)}
          >
            <i className="bi bi-sliders"></i>
            Filters
            {hasActiveFilters && (
              <span>
                {
                  [
                    category !== "All",
                    condition !== "All",
                    maxPrice < 10000,
                  ].filter(Boolean).length
                }
              </span>
            )}
          </button>
        </section>

        <section className="um-category-strip">
          <button
            type="button"
            className={category === "All" ? "active" : ""}
            onClick={() => setCategory("All")}
          >
            <span className="um-category-icon">
              <i className="bi bi-grid"></i>
            </span>
            <span>All</span>
          </button>

          {CATEGORIES.map((item) => (
            <button
              type="button"
              key={item}
              className={category === item ? "active" : ""}
              onClick={() => setCategory(item)}
            >
              <span className="um-category-icon">
                {item === "Furniture" && <i className="bi bi-lamp"></i>}
                {item === "Electronics" && <i className="bi bi-phone"></i>}
                {item === "Home & Living" && <i className="bi bi-house"></i>}
                {item === "Clothing" && <i className="bi bi-bag"></i>}
                {item === "Books" && <i className="bi bi-book"></i>}
                {item === "Decor" && <i className="bi bi-palette"></i>}
              </span>
              <span>{item}</span>
            </button>
          ))}
        </section>

        <div className="um-market-layout">
          <aside className={`um-filter-sidebar ${showFilters ? "open" : ""}`}>
            <div className="um-filter-header">
              <div>
                <span>Refine</span>
                <h3>Marketplace</h3>
              </div>

              <button type="button" onClick={() => setShowFilters(false)}>
                <i className="bi bi-x-lg"></i>
              </button>
            </div>

            <div className="um-filter-group">
              <label>Category</label>

              <div className="um-radio-list">
                <button
                  type="button"
                  className={category === "All" ? "selected" : ""}
                  onClick={() => setCategory("All")}
                >
                  <span></span>
                  All categories
                </button>

                {CATEGORIES.map((item) => (
                  <button
                    type="button"
                    key={item}
                    className={category === item ? "selected" : ""}
                    onClick={() => setCategory(item)}
                  >
                    <span></span>
                    {item}
                  </button>
                ))}
              </div>
            </div>

            <div className="um-filter-divider"></div>

            <div className="um-filter-group">
              <label>Condition</label>

              <div className="um-radio-list">
                <button
                  type="button"
                  className={condition === "All" ? "selected" : ""}
                  onClick={() => setCondition("All")}
                >
                  <span></span>
                  Any condition
                </button>

                {CONDITIONS.map((item) => (
                  <button
                    type="button"
                    key={item}
                    className={condition === item ? "selected" : ""}
                    onClick={() => setCondition(item)}
                  >
                    <span></span>
                    {item}
                  </button>
                ))}
              </div>
            </div>

            <div className="um-filter-divider"></div>

            <div className="um-filter-group">
              <div className="um-filter-label-row">
                <label>Maximum price</label>
                <strong>{formatPrice(maxPrice)}</strong>
              </div>

              <input
                className="um-price-range"
                type="range"
                min="500"
                max="10000"
                step="250"
                value={maxPrice}
                onChange={(event) => setMaxPrice(event.target.value)}
              />

              <div className="um-range-values">
                <span>₹500</span>
                <span>₹10,000+</span>
              </div>
            </div>

            {hasActiveFilters && (
              <button
                type="button"
                className="um-clear-filters"
                onClick={clearFilters}
              >
                <i className="bi bi-arrow-counterclockwise"></i>
                Clear all filters
              </button>
            )}
          </aside>

          {showFilters && (
            <div
              className="um-filter-overlay"
              onClick={() => setShowFilters(false)}
            ></div>
          )}

          <section className="um-results">
            <div className="um-results-toolbar">
              <div>
                <span className="um-results-label">Marketplace</span>

                <h2>
                  {filteredItems.length}{" "}
                  {filteredItems.length === 1 ? "item" : "items"}
                  <span> found</span>
                </h2>
              </div>

              <div className="um-toolbar-actions">
                <select
                  value={sort}
                  onChange={(event) => setSort(event.target.value)}
                  aria-label="Sort products"
                >
                  <option value="featured">Featured</option>
                  <option value="newest">Newest</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="rating">Highest Rated Seller</option>
                  <option value="co2">Most CO₂ Saved</option>
                </select>

                <div className="um-view-switch">
                  <button
                    type="button"
                    className={view === "grid" ? "active" : ""}
                    onClick={() => setView("grid")}
                  >
                    <i className="bi bi-grid-3x3-gap"></i>
                  </button>

                  <button
                    type="button"
                    className={view === "list" ? "active" : ""}
                    onClick={() => setView("list")}
                  >
                    <i className="bi bi-list"></i>
                  </button>
                </div>
              </div>
            </div>

            {filteredItems.length > 0 ? (
              <div
                className={`um-products ${
                  view === "list" ? "list-view" : "grid-view"
                }`}
              >
                {filteredItems.map((item) => (
                  <ProductCard
                    key={item.id}
                    item={item}
                    isWishlisted={wishlist.includes(item.id)}
                    onWishlist={toggleWishlist}
                  />
                ))}
              </div>
            ) : (
              <div className="um-empty-state">
                <div className="um-empty-icon">
                  <i className="bi bi-search"></i>
                </div>

                <h3>No items found</h3>

                <p>We couldn't find anything matching your current filters.</p>

                <button type="button" onClick={clearFilters}>
                  Clear filters
                </button>
              </div>
            )}
          </section>
        </div>
      </div>

      <section className="um-trust-section">
        <div className="um-container">
          <div className="um-trust-grid">
            <div className="um-trust-card">
              <div className="um-trust-icon">
                <i className="bi bi-recycle"></i>
              </div>
              <div>
                <strong>Circular by design</strong>
                <span>Every item gets another chance.</span>
              </div>
            </div>

            <div className="um-trust-card">
              <div className="um-trust-icon">
                <i className="bi bi-shield-check"></i>
              </div>
              <div>
                <strong>Community sellers</strong>
                <span>Discover people and verified ReMakers.</span>
              </div>
            </div>

            <div className="um-trust-card">
              <div className="um-trust-icon">
                <i className="bi bi-tree"></i>
              </div>
              <div>
                <strong>Measurable impact</strong>
                <span>See the impact behind your purchase.</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
