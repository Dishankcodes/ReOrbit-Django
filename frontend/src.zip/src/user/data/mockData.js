export const currentUser = {
  name: "Aarav Patel",
  firstName: "Aarav",
  username: "aarav_patel",
  email: "aarav.patel@example.com",
  city: "Ahmedabad",
  avatar: "/images/users/aarav-patel.jpg",
  points: 1840,
  level: "Impact Maker",
  itemsRescued: 18,
  orders: 7,
  wishlist: 12,
  following: 8,
  co2Saved: 26.4,
};

export const products = [
  { id: "teak-drawer-chest", title: "Restored teak drawer chest", category: "Furniture", price: 4200, image: "/images/products/teak-drawer-chest.jpg", seller: "Tara Bose", sellerType: "ReMaker", rating: 4.9, co2: 24, condition: "Excellent", location: "Kolkata" },
  { id: "vintage-reading-chair", title: "Vintage reading chair", category: "Furniture", price: 2800, image: "/images/products/vintage-chair.jpg", seller: "Rohan Shah", sellerType: "Community Seller", rating: 4.7, co2: 38, condition: "Very Good", location: "Pune" },
  { id: "ceramic-table-lamp", title: "Handmade ceramic table lamp", category: "Home & Living", price: 1650, image: "/images/products/ceramic-lamp.jpg", seller: "Arjun Mehta", sellerType: "ReMaker", rating: 4.9, co2: 12, condition: "Excellent", location: "Ahmedabad" },
  { id: "solid-wood-side-table", title: "Solid wood side table", category: "Furniture", price: 2200, image: "/images/products/wooden-table.jpg", seller: "Nisha Rao", sellerType: "Community Seller", rating: 4.6, co2: 31, condition: "Good", location: "Mumbai" },
  { id: "desk-lamp", title: "Refurbished desk lamp", category: "Electronics", price: 950, image: "/images/products/default-item.jpg", seller: "Kabir Verma", sellerType: "Community Seller", rating: 4.7, co2: 8, condition: "Very Good", location: "Delhi" },
  { id: "cotton-jacket", title: "Upcycled cotton jacket", category: "Clothing", price: 1450, image: "/images/products/default-item.jpg", seller: "Anaya Singh", sellerType: "Community Seller", rating: 4.9, co2: 6, condition: "Excellent", location: "Jaipur" },
  { id: "novel-collection", title: "Classic novel collection", category: "Books", price: 750, image: "/images/products/default-item.jpg", seller: "Tara Bose", sellerType: "Community Seller", rating: 4.8, co2: 5, condition: "Good", location: "Kolkata" },
  { id: "reclaimed-wall-decor", title: "Reclaimed wood wall decor", category: "Decor", price: 1250, image: "/images/products/default-item.jpg", seller: "Priya Shah", sellerType: "ReMaker", rating: 4.8, co2: 14, condition: "Excellent", location: "Surat" },
];

export const remakers = [
  { id: "tara-bose", name: "Tara Bose", craft: "Furniture & Wood Restoration", city: "Kolkata", image: "/images/remakers/tara-bose.jpg", rating: 4.9, followers: 1240, products: 18, rescued: 42, verified: true },
  { id: "arjun-mehta", name: "Arjun Mehta", craft: "Upcycled Home Decor", city: "Ahmedabad", image: "/images/remakers/arjun-mehta.jpg", rating: 4.8, followers: 980, products: 15, rescued: 36, verified: true },
  { id: "priya-shah", name: "Priya Shah", craft: "Textile & Lifestyle", city: "Mumbai", image: "/images/remakers/priya-shah.jpg", rating: 4.9, followers: 1510, products: 21, rescued: 51, verified: true },
];

export const orders = [
  { id: "RO-10482", product: "Restored teak drawer chest", seller: "Tara Bose", image: "/images/products/teak-drawer-chest.jpg", amount: 4200, status: "Delivered", date: "28 Sep 2026", delivery: "Delivered on 02 Oct" },
  { id: "RO-10377", product: "Handmade ceramic table lamp", seller: "Arjun Mehta", image: "/images/products/ceramic-lamp.jpg", amount: 1650, status: "In transit", date: "04 Oct 2026", delivery: "Expected 10 Oct" },
  { id: "RO-10291", product: "Vintage reading chair", seller: "Rohan Shah", image: "/images/products/vintage-chair.jpg", amount: 2800, status: "Processing", date: "06 Oct 2026", delivery: "Preparing for dispatch" },
];

export const wishlist = products.slice(0, 5);

export const notifications = [
  { id: 1, title: "Order on the move", text: "Your ceramic lamp is now in transit.", time: "18 min ago", unread: true, icon: "package" },
  { id: 2, title: "Orbit Points earned", text: "You earned 120 points from your latest order.", time: "2 hrs ago", unread: true, icon: "star" },
  { id: 3, title: "Wishlist reminder", text: "The restored teak chest is still available.", time: "Yesterday", unread: false, icon: "heart" },
];

export const activities = [
  { icon: "shopping-bag", title: "Purchased Handmade ceramic table lamp", time: "2 days ago", meta: "+120 points" },
  { icon: "heart", title: "Saved Vintage reading chair to wishlist", time: "4 days ago", meta: "Wishlist" },
  { icon: "user-plus", title: "Started following Priya Shah", time: "1 week ago", meta: "Following" },
  { icon: "gift", title: "Donated a cotton study chair", time: "2 weeks ago", meta: "+250 impact points" },
];

export const badges = [
  { icon: "leaf", title: "First Orbit", text: "Completed your first sustainable purchase.", earned: true, date: "12 Aug 2026" },
  { icon: "shopping-bag", title: "Circular Shopper", text: "Completed 5 marketplace purchases.", earned: true, date: "22 Sep 2026" },
  { icon: "heart", title: "Thoughtful Collector", text: "Saved 10 products to your wishlist.", earned: true, date: "30 Sep 2026" },
  { icon: "gift", title: "Community Giver", text: "Complete 3 donations to unlock this badge.", earned: false },
  { icon: "recycle", title: "Second Life", text: "Help rescue 25 items from waste.", earned: false },
  { icon: "trophy", title: "Impact Champion", text: "Reach 5,000 Orbit Points.", earned: false },
];

export const faqs = [
  ["How do I place an order?", "Open any product, review its details, and select Add to cart or Buy now. Your order will appear under My Orders once confirmed."],
  ["How do Orbit Points work?", "Orbit Points reward sustainable activity such as purchases, donations, reviews and community actions. Points can unlock badges and future rewards."],
  ["Can I return a product?", "Return eligibility depends on the product and seller. Open the order details to view the return policy attached to that purchase."],
  ["How can I follow a ReMaker?", "Open a ReMaker profile from the marketplace or Discover page and select Follow ReMaker. Their new work will then appear in Following."],
];

export const formatPrice = (value) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value);
