/* =========================================================
   REMAKER MARKETPLACE - UI DATA
   Built on top of the shared marketplace data so ReMakers see
   the same listings users see, plus the extra details a
   ReMaker needs before buying (materials, size, rework ideas).

   source "user"    -> Items table (a person's reusable item)
   source "remaker" -> ReMaker_Products table (finished piece)
   ========================================================= */

import {
  ITEMS,
  formatPrice,
  getRemakerById,
  getSellerFromItem,
  getSellerReviews as getBaseSellerReviews,
  getUserById,
} from "../../data/marketplaceData";

export { formatPrice };

const IMG = "/images/";

const EXTRA = {
  "teak-drawer-chest": {
    gallery: ["products/teak-drawer-chest.jpg", "portfolio/tara-teak-cabinet.jpg", "products/wooden-table.jpg"],
    materials: ["Solid teak", "Brass pulls"],
    dimensions: "92 × 45 × 78 cm",
    age: "About 50 years old",
    ideas: ["Entry console", "Wall shelf from the drawers", "Planter stand"],
  },
  "vintage-reading-chair": {
    gallery: ["products/vintage-chair.jpg", "portfolio/tara-chair.jpg", "products/wooden-table.jpg"],
    materials: ["Hardwood frame", "Wooden seat"],
    dimensions: "58 × 60 × 92 cm",
    age: "About 30 years old",
    ideas: ["Reupholstered accent chair", "Cane-back redo", "Garden seat"],
  },
  "ceramic-table-lamp": {
    gallery: ["products/ceramic-lamp.jpg", "portfolio/arjun-lamp.jpg", "products/default-item.jpg"],
    materials: ["Glazed ceramic", "Copper wiring"],
    dimensions: "Ø 24 × 41 cm",
    age: "Made in 2022",
    ideas: ["New linen shade", "Pendant conversion", "Planter base"],
  },
  "solid-wood-side-table": {
    gallery: ["products/wooden-table.jpg", "portfolio/tara-console.jpg", "products/vintage-chair.jpg"],
    materials: ["Solid sheesham"],
    dimensions: "45 × 45 × 55 cm",
    age: "About 15 years old",
    ideas: ["Resin-inlay top", "Painted accent table", "Bedside with a drawer"],
  },
  "refurbished-desk-lamp": {
    gallery: ["products/default-item.jpg", "products/ceramic-lamp.jpg"],
    materials: ["Steel arm", "LED holder"],
    dimensions: "18 × 18 × 46 cm",
    age: "About 4 years old",
    ideas: ["Industrial wall sconce", "Brass-finish respray", "Cable-art piece"],
  },
  "cotton-handloom-jacket": {
    gallery: ["portfolio/priya-jacket.jpg", "portfolio/priya-bag.jpg", "portfolio/priya-home.jpg"],
    materials: ["Handloom cotton", "Cotton lining"],
    dimensions: "Size M, chest 98 cm",
    age: "Made in 2025",
    ideas: ["Patchwork tote", "Cushion covers", "Kids' jacket"],
  },
  "classic-novel-collection": {
    gallery: ["products/default-item.jpg", "portfolio/priya-home.jpg"],
    materials: ["Paper", "Cloth-bound covers"],
    dimensions: "12 books, 20 × 13 cm each",
    age: "Mixed, 1980s to 2000s",
    ideas: ["Book-page lampshade", "Hidden-book box", "Paper-craft panels"],
  },
  "reclaimed-wall-decor": {
    gallery: ["portfolio/arjun-shelf.jpg", "portfolio/arjun-metal.jpg", "products/wooden-table.jpg"],
    materials: ["Reclaimed pine", "Natural oil finish"],
    dimensions: "90 × 30 × 4 cm",
    age: "New, from old wood",
    madeFrom: "Floor joists from a 1960s house in Surat",
  },
  "restored-teak-cabinet": {
    gallery: ["portfolio/tara-teak-cabinet.jpg", "products/teak-drawer-chest.jpg", "portfolio/tara-console.jpg", "portfolio/tara-chair.jpg"],
    materials: ["Teak", "Original brass hinges", "Plant-based wax"],
    dimensions: "110 × 40 × 85 cm",
    age: "Restored in 2026",
    madeFrom: "A teak cabinet rescued from a Kolkata home clear-out",
  },
  "reclaimed-wood-shelf": {
    gallery: ["portfolio/arjun-shelf.jpg", "portfolio/arjun-metal.jpg", "portfolio/arjun-lamp.jpg"],
    materials: ["Reclaimed wood", "Iron brackets"],
    dimensions: "75 × 22 × 18 cm",
    age: "New, from old wood",
    madeFrom: "Offcuts from a dismantled bookshelf",
  },
  "upcycled-home-lamp": {
    gallery: ["portfolio/arjun-lamp.jpg", "products/ceramic-lamp.jpg", "portfolio/arjun-metal.jpg"],
    materials: ["Recovered steel", "Brass", "Cloth cable"],
    dimensions: "Ø 20 × 52 cm",
    age: "New, from old parts",
    madeFrom: "An old industrial machine part",
  },
  "recovered-textile-bag": {
    gallery: ["portfolio/priya-bag.jpg", "portfolio/priya-jacket.jpg", "portfolio/priya-home.jpg"],
    materials: ["Recovered cotton", "Canvas lining"],
    dimensions: "38 × 32 × 12 cm",
    age: "New, from old fabric",
    madeFrom: "Discarded upholstery and denim offcuts",
  },
};

export const SERVICEABLE_PINCODES = [
  "380015", "380001", "380009", "380016", "560034", "411007",
  "400050", "110016", "302017", "700029", "395007",
];

/* ReOrbit-managed delivery is chargeable (Items.pickup_preference) */
export function deliveryCharge(price) {
  if (price < 1500) return 99;
  if (price < 5000) return 199;
  return 349;
}

export const MARKET_LISTINGS = ITEMS.map((item) => {
  const extra = EXTRA[item.id] || {};
  const gallery = (extra.gallery || []).map((path) => IMG + path);

  return {
    ...item,
    source: item.sellerType === "remaker" ? "remaker" : "user",
    gallery: gallery.length ? gallery : [item.image],
    materials: extra.materials || [],
    dimensions: extra.dimensions || "",
    age: extra.age || "",
    ideas: extra.ideas || [],
    madeFrom: extra.madeFrom || "",
  };
});

export const SOURCE_LABEL = {
  user: "Community item",
  remaker: "ReMaker piece",
};

export const MARKET_CATEGORIES = [...new Set(MARKET_LISTINGS.map((l) => l.category))].sort();

export const CONDITIONS = ["Excellent", "Very Good", "Good"];

export const SORTS = [
  { key: "newest", label: "Newest first" },
  { key: "popular", label: "Most saved" },
  { key: "price-low", label: "Price: low to high" },
  { key: "price-high", label: "Price: high to low" },
];

export function sortListings(list, key) {
  const copy = [...list];

  if (key === "popular") return copy.sort((a, b) => b.likes - a.likes);
  if (key === "price-low") return copy.sort((a, b) => a.price - b.price);
  if (key === "price-high") return copy.sort((a, b) => b.price - a.price);

  return copy.sort((a, b) => b.listedDate.localeCompare(a.listedDate));
}

export function getListingById(id) {
  return MARKET_LISTINGS.find((listing) => listing.id === id) || null;
}

export function getSeller(listing) {
  return getSellerFromItem(listing);
}

export function getRelatedListings(listing, limit = 4) {
  const same = MARKET_LISTINGS.filter(
    (other) => other.id !== listing.id && other.category === listing.category,
  );
  const rest = MARKET_LISTINGS.filter(
    (other) => other.id !== listing.id && other.category !== listing.category,
  );

  return [...same, ...rest].slice(0, limit);
}

/* ---------------------------------------------------------
   SELLER PROFILES
   A listing posted by a ReMaker opens the ReMaker profile,
   anything else opens the user (community seller) profile.
   --------------------------------------------------------- */

export function getSellerProfile(sellerId) {
  const remaker = getRemakerById(sellerId);
  if (remaker) return { type: "remaker", data: remaker };

  const user = getUserById(sellerId);
  if (user) return { type: "user", data: user };

  return null;
}

export function sellerProfilePath(sellerId) {
  return `/remaker-marketplace/seller/${sellerId}`;
}

export function getListingsBySeller(sellerId) {
  return MARKET_LISTINGS.filter((listing) => listing.sellerId === sellerId);
}

/* ---------------------------------------------------------
   REVIEWS
   Seller reviews come from the shared data, with a few added so
   every seller has something to show. Product reviews only exist
   for ReMaker pieces (made-to-repeat products). Community items
   are one-offs, so buyers review the seller instead.
   --------------------------------------------------------- */

const EXTRA_SELLER_REVIEWS = {
  "user-aarav-patel": [
    { id: "x-1", name: "Pooja", rating: 5, text: "Exactly as described. Aarav kept me updated until pickup.", date: "2026-09-09" },
    { id: "x-2", name: "Harsh", rating: 5, text: "Honest listing and well packed. Would buy again.", date: "2026-08-22" },
    { id: "x-3", name: "Devika", rating: 4, text: "Good communication, minor scuffs that were mentioned upfront.", date: "2026-08-03" },
  ],
  "user-nisha-rao": [
    { id: "x-4", name: "Amit", rating: 5, text: "The table was better than the photos suggested.", date: "2026-08-29" },
    { id: "x-5", name: "Sana", rating: 4, text: "Easy handover and fair price.", date: "2026-08-12" },
  ],
  "user-kabir-verma": [
    { id: "x-6", name: "Vikram", rating: 5, text: "Tested the lamp in front of me. Very transparent seller.", date: "2026-09-12" },
    { id: "x-7", name: "Ria", rating: 4, text: "Works perfectly, quick replies.", date: "2026-08-25" },
  ],
  "user-anaya-singh": [
    { id: "x-8", name: "Tanvi", rating: 5, text: "The stitching is lovely and the fabric feels great.", date: "2026-09-15" },
    { id: "x-9", name: "Manav", rating: 5, text: "Thoughtful seller. Packed it with care.", date: "2026-08-28" },
  ],
};

export function getSellerReviews(sellerId) {
  const base = getBaseSellerReviews(sellerId);
  return base.length ? base : EXTRA_SELLER_REVIEWS[sellerId] || [];
}

const PRODUCT_REVIEWS = {
  "restored-teak-cabinet": [
    { id: "p-1", name: "Aditi", rating: 5, text: "The grain is stunning and the doors close perfectly. It feels like it has always been in our hall.", date: "2026-09-18" },
    { id: "p-2", name: "Sameer", rating: 5, text: "Arrived well wrapped. The finish is smooth and the brass hinges are a nice touch.", date: "2026-09-04" },
    { id: "p-3", name: "Kavya", rating: 4, text: "Beautiful piece. A little heavier than I expected, so plan for two people.", date: "2026-08-27" },
  ],
  "reclaimed-wood-shelf": [
    { id: "p-4", name: "Dhruv", rating: 5, text: "Clean lines and very sturdy. Holds all my books without a wobble.", date: "2026-09-16" },
    { id: "p-5", name: "Riya", rating: 5, text: "The natural grain makes it look warmer than any shelf from a store.", date: "2026-09-01" },
  ],
  "upcycled-home-lamp": [
    { id: "p-6", name: "Nikhil", rating: 5, text: "Looks like a sculpture when it is switched off. The light is warm and even.", date: "2026-09-20" },
    { id: "p-7", name: "Ishaan", rating: 4, text: "Great build. I would have liked a slightly longer cable.", date: "2026-09-07" },
    { id: "p-8", name: "Leena", rating: 5, text: "Smart use of an old part. Got a lot of compliments.", date: "2026-08-24" },
  ],
  "recovered-textile-bag": [
    { id: "p-9", name: "Mansi", rating: 5, text: "Sturdy stitching and the patchwork is unique. I use it daily.", date: "2026-09-19" },
    { id: "p-10", name: "Ishita", rating: 5, text: "Roomy enough for a laptop and still looks great.", date: "2026-09-02" },
    { id: "p-11", name: "Pranav", rating: 4, text: "Love it. The strap could be a little longer.", date: "2026-08-19" },
  ],
  "reclaimed-wall-decor": [
    { id: "p-12", name: "Gauri", rating: 5, text: "The oil finish brings out the wood. Easy to hang.", date: "2026-09-21" },
    { id: "p-13", name: "Yash", rating: 4, text: "Nice minimal piece. Colour is slightly darker than the photos.", date: "2026-09-10" },
  ],
  "classic-novel-collection": [
    { id: "p-14", name: "Meghna", rating: 5, text: "Well kept and nicely bundled. A lovely set.", date: "2026-09-13" },
  ],
};

export function getProductReviews(listingId) {
  return PRODUCT_REVIEWS[listingId] || [];
}

export function summarizeReviews(reviews) {
  const distribution = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
  let sum = 0;

  reviews.forEach((review) => {
    distribution[review.rating] += 1;
    sum += review.rating;
  });

  return {
    count: reviews.length,
    average: reviews.length ? sum / reviews.length : 0,
    distribution,
  };
}
