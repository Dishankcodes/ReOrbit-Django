import { useState } from "react";
import { Outlet } from "react-router-dom";
import UserSidebar from "./UserSidebar";
import UserHeader from "./UserHeader";
import "./UserLayout.css";

export default function UserLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  return <div className={`user-shell ${collapsed ? "is-collapsed" : ""} ${mobileOpen ? "mobile-open" : ""}`}>
    <UserSidebar collapsed={collapsed} mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} />
    {mobileOpen && <button className="user-overlay" aria-label="Close menu" onClick={() => setMobileOpen(false)} />}
    <div className="user-main"><UserHeader onMenu={() => window.innerWidth <= 900 ? setMobileOpen(v => !v) : setCollapsed(v => !v)} /><main className="user-content"><Outlet /></main></div>
  </div>;
}
