import { NavLink, useNavigate } from "react-router-dom";
import { LayoutDashboard, Store, Package, Heart, Gift, Users, Star, Trophy, Settings, CircleHelp, LogOut, Leaf, X, ChevronRight } from "lucide-react";
import { currentUser } from "../data/mockData";
import "./UserSidebar.css";

const sections = [
  { label: "MAIN MENU", items: [["Dashboard","/user-dashboard",LayoutDashboard],["Marketplace","/user-marketplace",Store],["My Orders","/user-orders",Package],["Wishlist","/user-wishlist",Heart],["Donations","/user-donations",Gift],["Following","/user-following",Users]] },
  { label: "REWARDS", items: [["Orbit Points","/user-orbit-points",Star],["Badges","/user-badges",Trophy]] },
  { label: "SUPPORT", items: [["Settings","/user-settings",Settings],["Help & FAQ","/user-help",CircleHelp]] },
];
export default function UserSidebar({ collapsed, mobileOpen, onClose }) {
  const navigate = useNavigate();
  const logout = () => { ["reorbit_access_token","reorbit_refresh_token","reorbit_account_type","reorbit_user"].forEach(k => localStorage.removeItem(k)); navigate("/auth", { replace:true }); onClose?.(); };
  return <aside className={`user-sidebar ${collapsed ? "collapsed" : ""} ${mobileOpen ? "mobile-open" : ""}`}>
    <div className="sidebar-brand"><div className="brand-mark"><Leaf size={21}/></div><div className="brand-copy"><strong>ReOrbit</strong><span>REUSE · RECREATE · REIMAGINE</span></div><button className="sidebar-close" onClick={onClose}><X size={18}/></button></div>
    <nav className="sidebar-nav">{sections.map(section => <div className="sidebar-section" key={section.label}><span className="sidebar-label">{section.label}</span>{section.items.map(([label,path,Icon]) => <NavLink key={path} to={path} end={path === "/user-dashboard"} onClick={() => window.innerWidth <= 900 && onClose?.()} className={({isActive}) => `sidebar-link ${isActive ? "active" : ""}`}><Icon size={18}/><span>{label}</span></NavLink>) }{section.label === "SUPPORT" && <button className="sidebar-link logout" onClick={logout}><LogOut size={18}/><span>Logout</span></button>}</div>)}</nav>
    <button className="sidebar-profile" onClick={() => {navigate("/user-profile"); onClose?.()}}><img src={currentUser.avatar} alt=""/><span><strong>{currentUser.name}</strong><small>{currentUser.level}</small></span><ChevronRight size={16}/></button>
  </aside>;
}
